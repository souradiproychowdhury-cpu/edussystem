---
name: EduPulse University SMS
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464554'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#6b38d4'
  on-secondary: '#ffffff'
  secondary-container: '#8455ef'
  on-secondary-container: '#fffbff'
  tertiary: '#006577'
  on-tertiary: '#ffffff'
  tertiary-container: '#008096'
  on-tertiary-container: '#f9fdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  data-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an authoritative, elevated academic operations environment. Designed for university administrators, registrars, department heads, and faculty, the interface prioritizes high-throughput data legibility, cognitive composure, and operational confidence. 

The aesthetic is Modern Corporate SaaS balanced with subtle technical refinement. Interfaces combine structural clarity, high-density tabular ergonomics, crisp perimeter containment, and disciplined white space. The emotional experience balances institutional credibility with agile, state-of-the-art administrative velocity.

## Colors

The system uses an assertive institutional indigo (`#6366F1`) paired with an academic purple (`#8B5CF6`) for primary workflows, active navigation cues, and prominent calls to action. A focused cyan (`#06B6D4`) serves as an analytic accent for telemetry and real-time system signals.

Canvas surfaces utilize a cool, low-fatigue slate canvas (`#F8FAFC`), while containers sit on pure white (`#FFFFFF`) with subtle slate borders (`#E2E8F0`). High-density navigation rails, global search anchors, and executive command ribbons leverage deep midnight slate (`#0F172A`) to frame the workspace with clear spatial boundaries.

Functional status tokens adhere to strict semantic norms:
- **Success:** `#22C55E` (Enrollment cleared, degree audit passed, fees settled)
- **Warning:** `#F59E0B` (Prerequisite pending, waitlist capacity warning, visa expiry near)
- **Danger:** `#EF4444` (Academic probation, registration block, critical system alert)

## Typography

Typography pairs `Plus Jakarta Sans` for headers, structural titles, and high-impact metric counters with `Inter` for data grids, metadata ribbons, body copy, and form fields.

Numeric values inside data tables, GPA metrics, credit tallies, and student identification numbers should always enable tabular lining (`font-variant-numeric: tabular-nums`) to ensure strict vertical alignment across dense roster columns. Labels below 12px utilize slightly expanded tracking to maintain instant legibility on dense dashboards.

## Layout & Spacing

The interface is structured on a fluid 12-column administrative grid system flanked by a fixed-width deep slate navigation sidebar (pinned at 280px on desktop; collapsed to an icon-rail of 72px on compact monitors). 

Layout rules adhere strictly to an 8px base rhythm. Outer desktop canvas gutters sit at `1.5rem` (24px) with page margins at `2rem` (32px). On viewports below 1024px, the layout condenses into an 8-column layout, and below 768px transitions to a 4-column flow with collapsed mobile rails, top-level drawer controls, and horizontal-scrolling analytical card carousels.

## Elevation & Depth

Visual hierarchy uses a disciplined combination of low-contrast ghost outlines (`#E2E8F0`) and diffused, slate-tinted ambient shadows. Avoid heavy dropshadows; separation must remain clean and architectural.

- **Flat Canvas:** `#F8FAFC` base platform.
- **Card/Container Surface (Level 1):** `#FFFFFF` with a 1px continuous border (`#E2E8F0`) and ambient shadow `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
- **Interactive Hover & Flyouts (Level 2):** `#FFFFFF` with border (`#CBD5E1`) and elevated shadow `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Overlays, Modals, & Command Drawers (Level 3):** `#FFFFFF` anchored over a tinted slate backdrop (`#0F172A` at 40% opacity), supported by shadow `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`.

## Shapes

The geometric framework balances standard roundedness for cards, inputs, and functional containers with pill styling for transient labels, system badges, and identity tags.

Core containers (cards, data tables, modal dialogs) sit at standard `rounded` (0.5rem / 8px). Inner items like nested input groupings, calendar blocks, and sub-panels adapt to `rounded-sm` (0.25rem / 4px). Role pills, status indicator tags, and avatar chips adopt full pill geometry (`rounded-full` / 9999px) to establish visual contrast against the crisp angular boundaries of tabular forms.

## Components

### Buttons
- **Primary:** Solid `#6366F1` background, `#FFFFFF` text, `font-weight: 600`. On hover, transitions to `#4F46E5` with a subtle ring inset.
- **Secondary:** Transparent background, 1px border `#E2E8F0`, `#0F172A` text. On hover, background shifts to `#F1F5F9`.
- **Tertiary/Ghost:** No border, `#475569` text, background becomes `#F1F5F9` on hover.

### Badges & Role-Based Indicators
- Fully pill-shaped (`rounded-full`) using micro typography (`label-sm`).
- **Student:** Pale indigo surface (`#EEF2FF`), text `#4338CA`.
- **Faculty:** Pale purple surface (`#F5F3FF`), text `#6D28D9`.
- **Registrar / Admin:** Pale slate surface (`#F1F5F9`), text `#0F172A`.
- **Status Indicators:** Accompanied by a 6px circular indicator dot (e.g., `#22C55E` for Active/Good Standing).

### Metrics Counters
KPI widgets inside dashboards are wrapped in Level 1 elevated white cards:
- Label set in `label-md` uppercase (`#64748B`).
- Value rendered using `data-metric` in `#0F172A`.
- Trend deltas marked by small pill tags showing +/- percentage with directional icons in `#16A34A` or `#DC2626`.

### Data Grid Tables
- **Header:** Sticky `#F8FAFC` row, `label-sm` text uppercase in `#475569`, bottom border 1px solid `#CBD5E1`.
- **Rows:** Default `#FFFFFF`, hover row tint `#F8FAFC`. Height fixed at 48px for standard density and 40px for compact views. Bottom border 1px solid `#F1F5F9`.
- **Action Columns:** Right-aligned icon buttons (`#64748B`) that transition to `#0F172A` on interaction.

### Input Fields & Controls
- **Inputs:** 40px height, `#FFFFFF` background, 1px border `#CBD5E1`, text `#0F172A`. Focused state commands an indigo focus ring (`#6366F1` at 2px offset).
- **Checkboxes & Radios:** 16px square/circle with `#6366F1` fill when checked; white checked mark icon inset.

### Tab Navigation
Segmented underline tabs:
- Inactive tabs display `#64748B` with transparent bottom indicator border.
- Active tabs feature `#6366F1` text, semi-bold weight, and a 2px active bottom bar spanning the full width of the tab label.